package com
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import com.typesafe.config._
import ProductDetailTask._

	                    
/*class MeshServicesSimulation extends Simulation{
  
    val conf = ConfigFactory.load()
	val baseUrl = conf.getString("serviceURL")
	val scenarioName = "Mesh Service Simulation"
  	val httpProtocol = http.baseURL(baseUrl)

    val scn = scenario(scenarioName)
   .feed(productID)
   .exec(
       ProductDetailTask.productDetails
     
    )
     .exec(
       ProductListingTask.productListing
     
    )
    
     
     
                     
  setUp(scn.inject(rampUsers(10) over (5 seconds)))
                .protocols(httpProtocol)
                .assertions(global.successfulRequests.percent.gte(99))
                .assertions(global.responseTime.mean.gte(90))             
  
} */