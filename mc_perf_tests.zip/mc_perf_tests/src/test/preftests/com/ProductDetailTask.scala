package com

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import com.typesafe.config._

object ProductDetailTask {

   		   val productID = csv("devices.csv").circular
           val productDetails=exec(http("Product Details Service")
          .get("8181/products")
        
              )                                     
                                              
                                              
  
}