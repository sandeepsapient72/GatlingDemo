package com

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import com.typesafe.config._
import ProductDetailTask._

	                    
class RetailInvoiceMatching  extends Simulation {
  	val conf 		 = ConfigFactory.load()
    val baseUrl      = conf.getString("serviceURL")
	println(baseUrl)
	val scenarioName = "Retail Invoice Matching Simulation"
  	val httpProtocol = http.baseURL(baseUrl)
  	.acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8") //Here are the common headers
    .doNotTrackHeader("1")
    .acceptLanguageHeader("en-US,en;q=0.5")
    .acceptEncodingHeader("gzip, deflate")
     	
    val scn =scenario(scenarioName)
    	.exec(http("request_1").get("/"))
   	
   	     setUp(scn.inject(rampUsers(10) over (5 seconds)))
        .protocols(httpProtocol)
        .assertions(global.successfulRequests.percent.gte(9))
        .assertions(global.responseTime.mean.gte(7))       
       
  }