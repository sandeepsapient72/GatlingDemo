package com

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import com.typesafe.config._

object ProductListingTask {

   val productID = csv("devices.csv").circular
   
                  val productListing=exec(http("Product Listing Service")
          .get("8080/productlisting")
        
                   )                                     
                                              
                                              
  
}