/*package com
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import com.typesafe.config._	
	class DemoProductDetailPrefSimulation extends Simulation {
   val conf = ConfigFactory.load()
   val deviceids = csv("devices.csv").circular
   val baseUrl =  conf.getString("productbaseUrl")
                val httpProtocol = http.baseURL(baseUrl)

                val deviceProductServiceEndpoint = "/demo/products/${productId}"

                val scn = scenario("DemoProductDetailPrefSimulation_1")
                				.feed(deviceids)
                                .exec(http("request_1")
                                .get(deviceProductServiceEndpoint))
                 setUp(scn.inject(rampUsers(500) over (20 seconds)))
                .protocols(httpProtocol)
                .assertions(global.successfulRequests.percent.greaterThan(95))
                .assertions(global.responseTime.mean.lessThan(70))                
}
*/